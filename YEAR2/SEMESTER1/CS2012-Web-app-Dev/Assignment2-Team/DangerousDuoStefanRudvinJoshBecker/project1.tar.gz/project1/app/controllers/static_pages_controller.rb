#rails server -b $IP -p $PORT
#Require open uri for HTML parsing
require 'open-uri'
require 'net/http'

class StaticPagesController < ApplicationController
  before_action :logged_in_user, only: [:index, :edit, :update, :destroy]
  before_action :correct_user,   only: [:edit, :update]
  before_action :admin_user,     only: :destroy
  
  def home
    
  end

  def help
  end
  
  def about
    
    @liveData = []
    
    #Josh and Stefan, Live data
    
    def initHTML
      @entire_url = 'http://www.medicalnewstoday.com/categories/genetics'
      
      @html_doc = Nokogiri::HTML(open(@entire_url)) do |config|
        config.strict.nonet
      end

      @Entire = @html_doc.css(".headline strong").text
      
      @source = open(@entire_url, &:read)
      return @source
      
    end
    
    def parse()
      fullhtml = initHTML()
      
      fullhtml = fullhtml.to_s
      ary = []
      numberArray = [9,11,13,15,17,19,21,23]
      
      numberArray.each do |x|
        ary += [fullhtml.split(/<strong>(.*?)strong>/)[x]]
      end
      
      return ary
    end
  
    @liveData = parse()
    
  end
  
  def contact
  end
  
  def search
    
    #Josh's Search -- Trying to interact with the model as well as parse a file
    #Josh's parse file function
 
    def parseFile(fname)
      ary = []
      f = File.read(fname)
      f=f.split
      a = 0
      f.each do |i|
        if i[0..1] == "rs" && i.length == 9 && a < 4
          ary.push(i[2..8])
          #puts ary[a] Debugging
          a +=1
        end
      end
      #puts ary Debugging
      return ary
    end
    
    # Stefan's HTML parse functions: 
    
    # Final loop to incorporate searches into view. Josh/Stefan
    def systemLoop
      @finalArray = [] #Becomes array of arrays
      
      if params[:search].present? #First add the written search
        @search = params[:search]
        if @search =~ /\A\d{7}\z/ #RsID validation
         @finalArray += [stefanFunc(@search)]
        end
      end
      
      if params[:button] == "Our Text File"
        rsIDarray = parseFile("public/genotypes1.txt") ### PARSEFILE 2!
        rsIDarray.each do |rsID|
          @finalArray += [stefanFunc(rsID)]
        end
      end
    end
    
    #Stefan function to return rsID information
    def stefanFunc(rsID)
      @infoArray = []
      initHTML(rsID)
      @infoArray += [rsID]
      varArrayofArrays = [[1,'Molecule',0],[2,'Created',0],[6,'refSNP',0],[6,'Variation Viewer',0]]
      varArrayofArrays.each do |item|
        @infoArray += [parse(item[0],item[1],item[2])]
      end
      #Save search to model
      @search = Search.create(rsid: @infoArray[0], organism:@infoArray[1], moleculeType:@infoArray[2], variationClass:@infoArray[3], ancestralAllele:@infoArray[4], userId: '1' )
      @search.save!
      return @infoArray
    end
    
    def initHTML(rsID)
      @base_url = 'https://www.ncbi.nlm.nih.gov/projects/SNP/snp_ref.cgi?rs='
      @full_url = @base_url + rsID.to_s
      
      @html = Nokogiri::HTML(open(@full_url)) do |config|
        config.strict.nonet
      end
      # @Full has all the information we need, but it must be parsed properly
      @Full = @html.css("td .text10").text
    end
    
    def parse(number1, string, number2)
      return @Full.split(':')[number1].split(string)[number2]
    end
    
    systemLoop

  end

end