class Search < ApplicationRecord
  
end
