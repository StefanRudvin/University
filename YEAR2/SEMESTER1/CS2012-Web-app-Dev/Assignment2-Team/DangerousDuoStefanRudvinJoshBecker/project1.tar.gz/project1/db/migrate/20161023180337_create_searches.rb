class CreateSearches < ActiveRecord::Migration[5.0]
  def change
    create_table :searches do |t|
      t.integer :rsid
      t.string :organism
      t.string :moleculeType
      t.string :variationClass
      t.string :ancestralAllele
      t.string :userId

      t.timestamps
      
      
    end
  end
end
