package com.company;

class Vars {

    static int[] userIds = new int[] {
            20245,  // User 1 ID
            98355,  // User 2 ID etc.
            77644,
            56779,
            94145,
            12421,
            12405,
            21414,
    };

    // User 1 Books etc.
    private static String[] user1books = new String[]{
            "Harry Potter and The Philosopher's Stone",
            "Harry Potter and The Chamber of Secrets",
            "Harry Potter and The Prisoner of Azkaban",
            "Cracking the coding Interview"
    };
    private static String[] user2books = new String[]{
            "Harry Potter and The Chamber of Secrets",
            "Harry Potter and The Prisoner of Azkaban",
            "Harry Potter and The Order of the Phoenix",
            "Harry Potter and The Half-Blood Prince",
            ""
    };
    private static String[] user3books = new String[]{
            "Harry Potter and The Philosopher's Stone",
            "Harry Potter and The Chamber of Secrets",
            "Harry Potter and The Deathly Hallows",
            "Harry Potter and The Half-Blood Prince",
            "Concepts of Programming Languages"
    };
    private static String[] user4books = new String[]{
            "Harry Potter and The Chamber of Secrets",
            "Harry Potter and The Deathly Hallows",
            "Concepts of Programming Languages",
            "Harry Potter and The Philosopher's Stone"
    };
    private static String[] user5books = new String[]{
            "Harry Potter and The Chamber of Secrets",
            "Harry Potter and The Deathly Hallows",
            "Concepts of Programming Languages",
            "Harry Potter and The Philosopher's Stone"
    };
    private static String[] user6books = new String[]{
            "Harry Potter and The Chamber of Secrets",
            "Harry Potter and The Deathly Hallows",
            "Concepts of Programming Languages",
            "Harry Potter and The Philosopher's Stone",
            "To kill a mockingbird",
            "Hamilton the squirrel"
    };
    private static String[] user7books = new String[]{
            "Harry Potter and The Chamber of Secrets",
            "Harry Potter and The Deathly Hallows",
            "Concepts of Programming Languages",
            "Harry Potter and The Philosopher's Stone",
            "To kill a mocking bird haha",
            "What is love"
    };
    private static String[] user8books = new String[]{
            "Harry Potter and The Chamber of Secrets",
            "Harry Potter and The Deathly Hallows",
            "Concepts of Programming Languages",
            "Harry Potter and The Philosopher's Stone",
            "To kill a mockingbird",
            "Midget shortage"
    };

    // Add books here!
    static String[][] books = new String[][]{
            user1books,
            user2books,
            user3books,
            user4books,
            user5books,
            user6books,
            user7books,
            user8books,
    };

}
