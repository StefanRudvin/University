package mud;

import java.rmi.*;
import java.util.*;

public class MUDServiceImpl  implements MUDServiceInterface{

	/*
		Class modified from practicals.package practicals.rmishout.ShoutServiceImpl
	 */

	protected MUD MUDInstance;

	protected String MUDInstanceName;

	protected Map<String, MUD> Servers = new HashMap<String, MUD>();

	protected Integer MUDTotal = 0;
	protected Integer playerTotal = 0;

	private static final int MAX_USERS_PER_MUD = 10;
	private static final int MAX_NUM_OF_MUDS = 5;
	private static final int MAX_TOTAL_PLAYERS = 100;

	public MUDServiceImpl() throws RemoteException {
		Servers.put("sample", new MUD("narnia.edg", "narnia.msg", "narnia.thg"));
		Servers.put("aberdeen", new MUD("aberdeen.edg", "aberdeen.msg", "aberdeen.thg"));
		Servers.put("aberdeen2", new MUD("aberdeen.edg", "aberdeen.msg", "aberdeen.thg"));
		MUDTotal = 3;
	}

	public boolean createMUD(String name) throws RemoteException{
		if (MAX_NUM_OF_MUDS > MUDTotal) {
			Servers.put(name, new MUD("aberdeen.edg", "aberdeen.msg", "aberdeen.thg"));
			MUDTotal ++;
			return true;
		}
		return false;
	}

	public String getPlayerTotal() throws RemoteException{
		return playerTotal.toString();
	}

	public String getMUDTotal() throws RemoteException{
		return MUDTotal.toString();
	}

	public String getMUDPlayerTotal() throws RemoteException{
		return Integer.toString(MUDInstance.users.size());
	}

	public String introduction() throws RemoteException {
		return  "================================================================================================================================== \n" +
				"                                                      Welcome to " + MUDInstanceName + "!                                          \n" +
				"                                                      " + getMUDTotal() + " Total players online                                   \n" +
				"                                                      " + getMUDPlayerTotal() + " Players online in this MUD                       \n" +
				"==================================================================================================================================";
	}

	public String getStartLocation() throws RemoteException {
		return MUDInstance.startLocation();
	}

	public String getLocationInfo(String location) throws RemoteException {
		return MUDInstance.getVertex(location).toString();
	}

	public String moveDirection(String currentLocation, String direction, String username) throws RemoteException {
		return MUDInstance.moveThing(currentLocation, direction, username);
	}

	public boolean initializeUser(String username) throws RemoteException {
		if ((MUDInstance.users.size() <= MAX_USERS_PER_MUD) && (playerTotal < MAX_TOTAL_PLAYERS)) {
			MUDInstance.users.put(username, MUDInstance.startLocation());
			MUDInstance.addThing(MUDInstance.startLocation(), username);
			playerTotal ++;
			return true;
		}
		return false;
	}

	public String getObjectsAtLocation(String location) throws RemoteException {
		return MUDInstance.locationInfo(location);
	}

	public void takeItem(String item, String location) throws RemoteException {
		MUDInstance.deleteThing(location, item);
	}

	public void dropItem(String item, String location) throws RemoteException {
		MUDInstance.addThing(location, item);
	}

	public String changeMUD(String MUDName) throws RemoteException {
		MUDInstanceName = MUDName;
		MUDInstance = Servers.get(MUDName);

		return MUDName;
	}

	public void exitMUD(String username, String location) throws RemoteException {
		playerTotal --;
		MUDInstance.users.remove(username);
		takeItem(username, location);
	}

	public String getServersString() throws RemoteException {
		return Servers.keySet().toString().replaceAll("\\[|\\]","").replaceAll(","," ");
	}
}
